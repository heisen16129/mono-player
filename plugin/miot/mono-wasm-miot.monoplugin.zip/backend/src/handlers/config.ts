// MIoT 智能音箱插件 - 配置 Handler
// 翻译自 Go 源码: plugins/songloft-plugin-xiaomi/handlers/config_handler.go

import { jsonResponse } from '@songloft/plugin-sdk';
import type { Router, HTTPRequest } from '@songloft/plugin-sdk';
import { ConfigManager } from '../config/manager';
import { ConversationMonitor } from '../conversation/monitor';
import { Scheduler } from '../schedule/scheduler';
import { VoiceEngine } from '../voicecmd/engine';
import { normalizeMemoryMaxRecords } from '../memory';
import type { MemoryService } from '../memory';
import { setHostBaseUrl, callHostAPI } from '../utils/http';
import { setDebugLog } from '../utils/debug';
import type { SearchPriority } from '../types';
import { DEFAULT_MUSIC_API_MODELS } from '../mina/constants';

const SEARCH_PRIORITIES: SearchPriority[] = ['parallel', 'local_first', 'external_first'];

function normalizeSearchPriority(value: unknown): SearchPriority {
  return typeof value === 'string' && SEARCH_PRIORITIES.includes(value as SearchPriority)
    ? value as SearchPriority
    : 'parallel';
}

/** 解析请求体（兼容 Uint8Array 和 string） */
function parseBody(req: HTTPRequest): any {
  if (!req.body) return {};
  try {
    const str = typeof req.body === 'string'
      ? req.body
      : String.fromCharCode.apply(null, Array.from(req.body as Uint8Array));
    return JSON.parse(str);
  } catch {
    return {};
  }
}

/** 判断是否为本地回环地址 */
function isLoopbackAddress(host: string): boolean {
  if (!host) return false;
  let hostname = host;
  const protoIdx = host.indexOf('://');
  if (protoIdx >= 0) {
    const rest = host.slice(protoIdx + 3);
    const slashIdx = rest.indexOf('/');
    const colonIdx = rest.indexOf(':');
    hostname = rest.slice(0, slashIdx >= 0 ? slashIdx : (colonIdx >= 0 ? colonIdx : undefined));
  }
  hostname = hostname.toLowerCase().trim();
  return hostname === 'localhost' || hostname.startsWith('127.') || hostname === '::1';
}

/** 获取服务器地址状态 */
function getServerHostStatus(host: string): string {
  if (!host) return 'empty';
  if (isLoopbackAddress(host)) return 'loopback';
  return 'ok';
}

/**
 * 注册配置相关路由
 * GET  /config → 获取配置
 * POST /config → 更新配置
 */
export function registerConfigHandlers(
  router: Router,
  configManager: ConfigManager,
  conversationMonitor: ConversationMonitor,
  scheduler: Scheduler,
  voiceEngine: VoiceEngine,
  memoryService: MemoryService,
): void {

  // GET /config - 获取配置
  router.get('/config', async (req: HTTPRequest) => {
    try {
      const config = await configManager.getConfig();
      const aiConfig = await configManager.getAIConfig();

      let suggestedAddresses: string[] = [];
      try {
        suggestedAddresses = await songloft.plugin.getNetworkAddresses();
      } catch {}

      return jsonResponse({
        success: true,
        data: {
          server_host: (globalThis as any).monoServerHost?.() ?? config.server_host,
          server_host_mode: config.server_host_mode || 'auto',
          conversation_monitor_enabled: config.conversation_monitor_enabled,
          voice_command_enabled: config.voice_command_enabled,
          voice_memory_enabled: config.voice_memory_enabled,
          voice_memory_max_records: config.voice_memory_max_records,
          scheduled_tasks_enabled: config.scheduled_tasks_enabled,
          timezone: config.timezone,
          force_mp3: !!config.force_mp3,
          radio_force_mp3: !!config.radio_force_mp3,
          volume_normalize: !!config.volume_normalize,
          song_transition_offset: config.song_transition_offset ?? 0,
          external_search_enabled: !!config.external_search_enabled,
          external_search_url: config.external_search_url || '',
          external_search_token: config.external_search_token || '',
          external_search_sources: config.external_search_sources || [],
          external_search_playlist_id: config.external_search_playlist_id ?? '',
          external_search_timeout: config.external_search_timeout ?? 6,
          external_search_no_import: !!config.external_search_no_import,
          search_priority: normalizeSearchPriority(config.search_priority),
          music_api_model_disabled: config.music_api_model_disabled || [],
          music_api_model_defaults: [...DEFAULT_MUSIC_API_MODELS],
          indicator_light_enabled: !!config.indicator_light_enabled,
          interrupt_tts_hint_enabled: !!config.interrupt_tts_hint_enabled,
          interrupt_tts_hint_text: config.interrupt_tts_hint_text || '正在搜索，请稍候',
          play_announcement_enabled: !!config.play_announcement_enabled,
          play_announcement_template: config.play_announcement_template || '即将播放{artist}的{song}',
          play_announcement_wait_mode: config.play_announcement_wait_mode || 'auto',
          play_announcement_delay: config.play_announcement_delay ?? 3,
          play_announcement_scope: config.play_announcement_scope || 'voice',
          conversation_poll_interval: config.conversation_poll_interval ?? 1,
          debug_log_enabled: !!config.debug_log_enabled,
          smart_resume_timeout: config.smart_resume_timeout ?? 30,
          max_song_index: config.max_song_index ?? 10000,
          server_host_status: getServerHostStatus((globalThis as any).monoServerHost?.() ?? config.server_host),
          suggested_addresses: suggestedAddresses,
          ai_config: aiConfig,
          default_cover_id: config.default_cover_id,
          touchscreen_lyrics_enabled: !!config.touchscreen_lyrics_enabled,
        },
      });
    } catch (e: any) {
      return jsonResponse({ success: false, error: e.message || String(e) }, 500);
    }
  });

  // POST /config - 更新配置
  router.post('/config', async (req: HTTPRequest) => {
    try {
      const body = parseBody(req);
      const config = await configManager.getConfig();
      let memoryMaxChanged = false;

      // 更新 server_host
      if (body.server_host_mode === 'auto' || body.server_host_mode === 'manual') config.server_host_mode = body.server_host_mode;
      if (body.server_host !== undefined) {
        if (body.server_host_mode === undefined) config.server_host_mode = 'manual';
        let serverHost = typeof body.server_host === 'string' ? body.server_host.trim() : '';
        if (serverHost && !serverHost.startsWith('http://') && !serverHost.startsWith('https://')) {
          serverHost = 'http://' + serverHost;
        }
        config.server_host = serverHost;
        setHostBaseUrl(serverHost);
      }

      // 更新 timezone
      if (body.timezone !== undefined) {
        config.timezone = body.timezone;
      }

      // 记录本次是否需要联动 Monitor 启停（在 saveConfig 之后再执行，
      // 保证「先保存配置、再启停监听器」，且 start() 会 await 到设备列表初始化完成）
      let monitorAction: 'start' | 'stop' | 'restart' | null = null;

      // 更新 conversation_monitor_enabled（联动 Monitor 启停）
      if (body.conversation_monitor_enabled !== undefined) {
        const enabled = !!body.conversation_monitor_enabled;
        config.conversation_monitor_enabled = enabled;
        monitorAction = enabled ? 'start' : 'stop';
      }

      // 更新 voice_command_enabled
      if (body.voice_command_enabled !== undefined) {
        const enabled = !!body.voice_command_enabled;
        config.voice_command_enabled = enabled;
        voiceEngine.setEnabled(enabled);
      }

      if (body.voice_memory_enabled !== undefined) {
        config.voice_memory_enabled = !!body.voice_memory_enabled;
      }

      if (body.voice_memory_max_records !== undefined) {
        config.voice_memory_max_records = normalizeMemoryMaxRecords(body.voice_memory_max_records);
        memoryMaxChanged = true;
      }

      // 更新 force_mp3
      if (body.force_mp3 !== undefined) {
        config.force_mp3 = !!body.force_mp3;
      }

      // 更新 radio_force_mp3（电台转码）
      if (body.radio_force_mp3 !== undefined) {
        config.radio_force_mp3 = !!body.radio_force_mp3;
      }

      // 更新 volume_normalize（音量均衡）
      if (body.volume_normalize !== undefined) {
        config.volume_normalize = !!body.volume_normalize;
      }

      // 更新 song_transition_offset（切歌偏移秒数，负数提前 / 正数推后）
      // 夹到 ±30 秒，与前端输入框的同一区间（static/js/config.js）对齐
      if (body.song_transition_offset !== undefined) {
        const offset = Number(body.song_transition_offset);
        if (Number.isFinite(offset)) {
          config.song_transition_offset = Math.max(-30, Math.min(30, Math.round(offset)));
        }
      }

      // 更新 external_search_url
      if (body.external_search_url !== undefined) {
        config.external_search_url = typeof body.external_search_url === 'string' ? body.external_search_url.trim() : '';
      }

      // 更新 external_search_token
      if (body.external_search_token !== undefined) {
        config.external_search_token = typeof body.external_search_token === 'string' ? body.external_search_token.trim() : '';
      }

      // 更新 external_search_sources（源列表，数组顺序即优先级）
      if (body.external_search_sources !== undefined) {
        config.external_search_sources = Array.isArray(body.external_search_sources)
          ? body.external_search_sources
              .filter((s: any) => s && typeof s.url === 'string' && s.url.trim())
              .map((s: any) => ({
                id: (typeof s.id === 'string' && s.id) ? s.id : `src_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
                name: typeof s.name === 'string' ? s.name.trim() : '',
                url: s.url.trim(),
                token: typeof s.token === 'string' ? s.token.trim() : '',
                enabled: s.enabled !== false,
              }))
          : [];
      }

      // 更新 external_search_enabled
      if (body.external_search_enabled !== undefined) {
        config.external_search_enabled = !!body.external_search_enabled;
      }

      // 更新 external_search_playlist_id
      if (body.external_search_playlist_id !== undefined) {
        config.external_search_playlist_id = typeof body.external_search_playlist_id === 'string'
          ? body.external_search_playlist_id.trim()
          : String(body.external_search_playlist_id);
      }

      // 更新 external_search_timeout
      if (body.external_search_timeout !== undefined) {
        config.external_search_timeout = Math.max(3, Math.min(60, Number(body.external_search_timeout) || 6));
      }

      // 更新 external_search_no_import
      if (body.external_search_no_import !== undefined) {
        config.external_search_no_import = !!body.external_search_no_import;
      }

      // 更新 search_priority
      if (body.search_priority !== undefined) {
        config.search_priority = normalizeSearchPriority(body.search_priority);
      }

      // 更新 indicator_light_enabled
      if (body.indicator_light_enabled !== undefined) {
        config.indicator_light_enabled = !!body.indicator_light_enabled;
      }

      // 更新 touchscreen_lyrics_enabled
      if (body.touchscreen_lyrics_enabled !== undefined) {
        config.touchscreen_lyrics_enabled = !!body.touchscreen_lyrics_enabled;
      }

      // ▼ 新增这段保存逻辑：接收前端传来的值并存入 config ▼
      if (body.default_cover_id !== undefined) {
        config.default_cover_id = String(body.default_cover_id).trim();
      }

      // 更新 interrupt_tts_hint_enabled
      if (body.interrupt_tts_hint_enabled !== undefined) {
        config.interrupt_tts_hint_enabled = !!body.interrupt_tts_hint_enabled;
      }

      // 更新 interrupt_tts_hint_text
      if (body.interrupt_tts_hint_text !== undefined) {
        config.interrupt_tts_hint_text = typeof body.interrupt_tts_hint_text === 'string'
          ? body.interrupt_tts_hint_text.trim()
          : '正在搜索，请稍候';
      }

      // 更新播放公告配置
      if (body.play_announcement_enabled !== undefined) {
        config.play_announcement_enabled = !!body.play_announcement_enabled;
      }
      if (body.play_announcement_template !== undefined) {
        config.play_announcement_template = typeof body.play_announcement_template === 'string'
          ? body.play_announcement_template.trim()
          : '即将播放{artist}的{song}';
      }
      if (body.play_announcement_wait_mode !== undefined) {
        const mode = String(body.play_announcement_wait_mode);
        if (mode === 'auto' || mode === 'fixed' || mode === 'poll') {
          config.play_announcement_wait_mode = mode;
        }
      }
      if (body.play_announcement_delay !== undefined) {
        config.play_announcement_delay = Math.max(0, Math.min(10, Number(body.play_announcement_delay) || 3));
      }
      if (body.play_announcement_scope !== undefined) {
        const scope = String(body.play_announcement_scope);
        if (scope === 'voice' || scope === 'all') {
          config.play_announcement_scope = scope;
        }
      }

      // 更新 conversation_poll_interval（联动 Monitor 重启）
      if (body.conversation_poll_interval !== undefined) {
        const val = Math.max(1, Math.min(30, Number(body.conversation_poll_interval) || 1));
        config.conversation_poll_interval = val;
        // 仅在监听器本次未被显式关闭时才重启（避免与上面的 stop 冲突）
        if (config.conversation_monitor_enabled && monitorAction !== 'stop') {
          monitorAction = 'restart';
        }
      }

      // 更新 debug_log_enabled（同步到 debug 模块的缓存，热路径靠它门控日志）
      if (body.debug_log_enabled !== undefined) {
        config.debug_log_enabled = !!body.debug_log_enabled;
        setDebugLog(config.debug_log_enabled);
      }

      // 更新 smart_resume_timeout
      if (body.smart_resume_timeout !== undefined) {
        config.smart_resume_timeout = Math.max(5, Math.min(120, Number(body.smart_resume_timeout) || 30));
      }

      // 更新 max_song_index
      if (body.max_song_index !== undefined) {
        config.max_song_index = Math.max(1000, Math.min(100000, Number(body.max_song_index) || 10000));
      }

      // 更新 music_api_model_disabled（显式禁用 Music API 的型号清单）
      if (body.music_api_model_disabled !== undefined) {
        config.music_api_model_disabled = Array.isArray(body.music_api_model_disabled)
          ? body.music_api_model_disabled
              .filter((m: any) => typeof m === 'string' && m.trim())
              .map((m: string) => m.trim().toUpperCase())
          : [];
      }

      // 更新 ai_config
      if (body.ai_config !== undefined) {
        const aiConfig = await configManager.getAIConfig();
        const newAI = body.ai_config as Record<string, unknown>;
        if (typeof newAI.enabled === 'boolean') {
          aiConfig.enabled = newAI.enabled;
        }
        if (typeof newAI.api_url === 'string') {
          aiConfig.api_url = newAI.api_url;
        }
        if (typeof newAI.api_key === 'string') {
          aiConfig.api_key = newAI.api_key;
        }
        if (typeof newAI.model === 'string') {
          aiConfig.model = newAI.model;
        }
        if (typeof newAI.timeout === 'number') {
          aiConfig.timeout = newAI.timeout;
        }
        await configManager.saveAIConfig(aiConfig);
      }

      // 更新 scheduled_tasks_enabled（联动 Scheduler 启停）
      if (body.scheduled_tasks_enabled !== undefined) {
        const enabled = !!body.scheduled_tasks_enabled;
        config.scheduled_tasks_enabled = enabled;
        if (enabled) {
          scheduler.start();
        } else {
          scheduler.stop();
        }
      }

      await configManager.saveConfig(config);

      let memoryWarning = '';
      if (memoryMaxChanged) {
        try {
          await memoryService.setMaxRecords(config.voice_memory_max_records);
          await memoryService.init();
          if (!(await memoryService.trimToLimit())) {
            memoryWarning = '最大记忆数量已保存，但现有记忆暂时无法完成淘汰。';
          }
        } catch (e) {
          memoryWarning = '最大记忆数量已保存，但现有记忆暂时无法完成淘汰。';
          songloft.log.warn('[MemoryConfig] trim failed: ' + String(e));
        }
      }

      // 配置保存后再联动监听器启停：start() 会 await 到设备列表初始化完成，
      // 之后前端请求 /conversation/status 即可拿到真实设备数量
      if (monitorAction === 'start' || monitorAction === 'restart') {
        conversationMonitor.stop();          // 先清理旧状态（含残留设备）
        await conversationMonitor.start();   // 再干净启动并等待初始化
      } else if (monitorAction === 'stop') {
        conversationMonitor.stop();
      }

      // 检查保存后的地址是否有效，附带 warning
      let warning = '';
      if (!config.server_host) {
        warning = '服务器地址为空，MIoT 智能音箱将无法播放音乐。请配置局域网 IP 地址（如 http://192.168.x.x:58091）。';
      } else if (isLoopbackAddress(config.server_host)) {
        warning = '检测到服务器地址为本地回环地址，MIoT 智能音箱将无法通过此地址访问服务器播放音乐。请使用局域网 IP 地址。';
      }
      if (memoryWarning) {
        warning = warning ? `${warning} ${memoryWarning}` : memoryWarning;
      }

      const resp: any = { success: true };
      if (warning) {
        resp.warning = warning;
      }
      return jsonResponse(resp);
    } catch (e: any) {
      return jsonResponse({ success: false, error: e.message || String(e) }, 500);
    }
  });

  // GET /search-providers - 获取可用的外部搜索提供方列表
  // 内置 knownProviders（fallback）+ 其他插件经 comm 动态注册的候选，按 entryPath 去重
  // （注册表优先，可覆盖内置元数据），再做 installed/active 校验。响应结构对前端保持不变。
  router.get('/search-providers', async (_req: HTTPRequest) => {
    interface ProviderCandidate {
      entryPath: string;
      name: string;
      searchPath: string;
      icon?: string;
    }

    // 候选来源：其他插件经 comm 动态注册的搜索提供方（仅真实安装的才展示）
    const byEntryPath = new Map<string, ProviderCandidate>();

    try {
      const registered = await configManager.getSearchProviders();
      for (const r of registered) {
        byEntryPath.set(r.entryPath, {
          entryPath: r.entryPath,
          name: r.name || r.entryPath,
          searchPath: r.searchPath || '/api/search/topone',
          icon: r.icon,
        });
      }
    } catch (e) {
      songloft.log.warn('[config] Failed to load registered search providers: ' + String(e));
    }

    interface HostPlugin {
      entry_path: string;
      status: string;
    }

    let installedPlugins: HostPlugin[] = [];
    try {
      const data = await callHostAPI<{ plugins: HostPlugin[] }>('GET', '/api/v1/jsplugins/');
      installedPlugins = data.plugins || [];
    } catch (e) {
      songloft.log.warn('[config] Failed to fetch plugin list: ' + String(e));
    }

    // 只返回真实安装（且已启用）的搜索提供方，过滤未安装的内置兜底项
    const providers = Array.from(byEntryPath.values())
      .map((p) => {
        const found = installedPlugins.find((ip) => ip.entry_path === p.entryPath);
        return {
          id: p.entryPath,
          name: p.name,
          url: `/api/v1/jsplugin/${p.entryPath}${p.searchPath}`,
          installed: !!found,
          active: found?.status === 'active',
          ...(p.icon ? { icon: p.icon } : {}),
        };
      })
      .filter((p) => p.installed && p.active);

    return jsonResponse({ providers });
  });
}
